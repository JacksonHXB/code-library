<template>
    <div>
        <h1>这是GoodsList组件</h1>
    </div>
</template>

<script></script>

<style></style>


