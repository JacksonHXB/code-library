//注意：App这个组件，通过VM实例的render函数渲染出来的，render函数渲染出来的组件，只能放在el:'#app'所指定的元素中
//Account和GoodsList组件，是通过路由匹配监听到的，所以这两个组件，只能展示到属于路由的<router-view></router-view>中



