<template>
    <div>
        <h1>这是login登录组件</h1>
    </div>
</template>

<script></script>

<!-- scoped 限制样式范围 -->
<style scoped> 
div{
    color: red;
}
</style>
