<template>
    <div>
        <h1>这是Register组件</h1>
    </div>
</template>

<script></script>

<style></style>
